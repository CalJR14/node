const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Configurar el motor de vistas
app.set('view engine', 'ejs'); // Asegúrate de instalar ejs con `npm install ejs`
app.set('views', path.join(__dirname, 'views'));

// Middleware para archivos estáticos
app.use(express.static(path.join(__dirname, 'public')));

// Rutas
app.get('/', (req, res) => {
res.render('home', { title: 'Inicio' });
});

app.get('/about', (req, res) => {
res.render('about', { title: 'Acerca de' });
});

// Iniciar el servidor
app.listen(PORT, () => {
console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
